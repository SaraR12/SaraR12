# SSY191 Individual Assignment 2

In this assignment there are two problems to be solved. You submit the assignment by writing a report, put it as pdf-file in the report directory. You should also submit the code for both Problem A and Problem B.

Each problem includes a Makefile that you can run to compile the code, just execute make in the terminal window. If the compilation is successfull you will then get an executable file that you can run.

# Problem 1
You only need to put in the changes to the code so that it avoids a deadlock - according to the instructions. The code does not necessarily have to be executable. 

# Problem 2
You are given skelton code that you can compile and run. Modify the file to fullfill the specifications given in Problem 2.

# Submission
Use the Linux git commands to add files, commit and push. See instructions given for group project 4. The teaching assistant will then be able to download your repository and check/execute the code that you have submitted. You should have pushed to GitHub before the submission deadline.
